Lokal: index.html
Online: http://infographics.oxid.ch/golfstromslides/