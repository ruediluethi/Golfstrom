%Umgebung
T01 = 1.9;
T02 = 0.8;
S01 = 1.7;
S02 = 0.5;

%Golfstrom
%T1 = 1.2;
%T2 = 0.8;


%Propfaktoren
a = 1;
b = 1;
c = 1;
kT = 1;
kS = 0.3;
